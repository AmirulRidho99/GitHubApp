package com.github.api.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.github.api.R
import com.github.api.data.User

class MainAdapter(val list: List<User>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var onItemClickListener: ((User) -> Unit)? = null
    inner class viewHolder : RecyclerView.ViewHolder {

        fun bind(user: User) {
            with(itemView) {
                Glide.with(this).load(user.avatarUrl).into(itemAvatar)
                itemlogin.text = user.login
                itemdescription.text = user.htmlUrl
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
       val view = LayoutInflater.from(parent.context).inflate(R.layout.item_main, parent, false )
        return viewHolder(view)
    }

    override fun getItemCount(): Int {
        holder.bind(list.get(position))
        holder.itemView. setOnclickListener{
            onItemClickListener.invoke(list[position])
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
       return list.size
    }
}