package com.github.api

import android.app.SearchManager
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.api.adapter.MainAdapter
import com.github.api.data.UserKOKO

private var MainActivity.queryHint: String
    get() {}
    set() {}

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adapter = MainAdapter(UserKOKO.list)
        adapter. onItemClickListener = {
            Toast.makeText(this, it. toString(), Toast.LENGTH_SHORT).show()
        }

        recyclerMain.adapter = adapter
        recyclerMain. layoutManager = LinearLayoutManager(this)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_bar, menu)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu?.findItem(R.id.search)?.actionView as SearchView


        this.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        this.queryHint = resources.getString(R.string.search_hint)

        searchView.run {


            setSearchableInfo(searchManager.getSearchableInfo(componentName))
            queryHint = resources.getString(R.string.search_hint)

            setOnQueryTextFocusChangeListener(onQueryTextListener = object : SearchView. OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    Toast.makeText(this@MainActivity,query, Toast.LENGTH_SHORT).show()
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    return false
                }

            })
        }
        return super.onCreateOptionsMenu(menu)
    }
}

private fun SearchView.setOnQueryTextFocusChangeListener(onQueryTextListener: SearchView.OnQueryTextListener) {
    TODO("Not yet implemented")
}
